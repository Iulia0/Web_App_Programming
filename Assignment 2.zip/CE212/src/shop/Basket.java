package shop;

import java.util.*;

public class Basket {

    Map<Product, Integer> items;
    ShopDB db;

    public static void main(String[] args) {
        Basket b = new Basket();
        b.addItem("art1");
        System.out.println( b.getTotalString() );
        b.clearBasket();
        System.out.println( b.getTotalString() );
        // check that adding a null String causes no problems
        String pid = null;
        b.addItem( pid );
        System.out.println( b.getTotalString() );
        b.addItem("art2");
        b.addItem("art1");
        b.addItem("art2");
        b.addItem("art2");
        b.addItem("art2");
        b.addItem("art3");
        b.addItem("art1");
        b.addItem("art3");
        b.addItem("art2");
        System.out.println(b.items);
        b.removeProduct("art1");
        System.out.println(b.items);
        b.removeProduct("art2");
        System.out.println(b.items);
        b.changeQuantity("art3", 1);
        System.out.println(b.items);
        b.addItem("AA01-005");
        System.out.println(b.items);
        b.changeQuantity("AA01-005", 1);
        System.out.println(b.items);

    }


    public Basket() {
        db = ShopDB.getSingleton();
        items = new HashMap<>();
    }

    /**
     *
     * @return Collection of Product items that are stored in the basket
     *
     * Each item is a product object - need to be clear about that...
     *
     * When we come to list the Basket contents, it will be much more
     * convenient to have all the product details as items in this way
     * in order to calculate that product totals etc.
     *
     */
    public Map<Product, Integer> getItems() {
        return items;
    }

    /**
     * empty the basket - the basket should contain no items after calling this method
     */
    public void clearBasket() {
        items.clear();
    }

    /**
     *
     *  Adds an item specified by its product code to the shopping basket
     *
     * @param pid - the product code
     */
    public void addItem(String pid) {

        // need to look the product name up in the
        // database to allow this kind of item adding...

        addItem( db.getProduct( pid ) );

    }

    public void addItem(Product p) {
        // ensure that we don't add any nulls to the item list
        if (p != null) {
            if (items.isEmpty()){
                items.put(p, 1);
            }
            else{
                boolean duplicate = true;
                for (Map.Entry<Product, Integer> entry : items.entrySet()) {
                    if (entry.getKey().title.equals(p.title)) {
                        items.put(entry.getKey(), entry.getValue() + 1);
                        duplicate = false;
                        break;
                    }
                }
                if (duplicate){
                    items.put(p, 1);
                }
            }
        }
    }

    /**
     *
     * @return the total value of items in the basket in pence
     */
    public int getTotal() {
        int price = 0;
        for (Map.Entry<Product, Integer> m : items.entrySet()){
            price += m.getKey().price * m.getValue();
        }

        // iterate over the set of products...

        // return the total
        return price;
    }

    /**
     *
     * @return the total value of items in the basket as
     * a pounds and pence String with two decimal places - hence
     * suitable for inclusion as a total in a web page
     */
    public String getTotalString() {
        int getTotal = getTotal();
        String price = String.valueOf(getTotal / 100) + "." + String.valueOf(getTotal % 100);
        return price ;
    }
    public void removeProduct(String product) {
        for (Map.Entry<Product, Integer> entry : items.entrySet()) {
            if (entry.getKey().PID.equals(product)) {
                items.remove(entry.getKey());
                break;
            }
        }
    }
    public void changeQuantity(String pid, int quantity){
        for (Map.Entry<Product, Integer> entry : items.entrySet()) {
            if (entry.getKey().PID.equals(pid)) {
                if (entry.getValue() != 0) {
                    items.put(entry.getKey(), entry.getValue() + quantity);
                }
            }
        }
    }

}
